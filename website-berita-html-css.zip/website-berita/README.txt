WEBSITE BERITA - HTML & CSS

Cara membuka:
1. Extract folder ini jika masih ZIP.
2. Buka VS Code.
3. Pilih File > Open Folder.
4. Pilih folder "website-berita".
5. Buka index.html.
6. Untuk preview mudah, install extension "Live Server" di VS Code.
7. Klik kanan index.html > Open with Live Server.

File:
- index.html  = halaman utama
- berita.html  = contoh halaman detail berita
- style.css   = semua styling

Catatan QR Code:
Saat website sudah online, URL setiap halaman berita dapat dijadikan QR Code.
Contoh:
https://domainkamu.com/berita/judul-berita

Versi ini sengaja dibuat HTML + CSS saja agar mudah dipelajari.
